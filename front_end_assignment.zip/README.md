# DeepThought Frontend Assignment (Option 5)

## What I built
A small React frontend that matches the assignment brief:
- Dynamic content controlled by a local variable `initialData` in `src/App.jsx`.
- Simple, clean UI to demonstrate the frontend and the use of a local variable to make the page dynamic.
- No external CSS frameworks required.

## Files
- `package.json` - project metadata and scripts (vite dev/build).
- `index.html` - Vite entry.
- `src/main.jsx` - React entry point.
- `src/App.jsx` - The LandingPage / main component. Edit `initialData` here to change content.
- `src/styles.css` - Simple styles.

## How to run locally
1. Install Node.js (v18+ recommended).
2. Run:
   ```
   npm install
   npm run dev
   ```
3. Open the URL shown by Vite (usually http://localhost:5173).

## What they are asking (explained)
The assignment expects:
- Build the frontend UI based on provided Figma/spreadsheet.
- Include a local variable to make the page dynamic (so content can be changed without editing markup).
- Deliver a working page that can be reviewed.

This project contains that: `initialData` is the local variable. Update it to match Figma text, images and modules.

## Next steps / improvements
- Replace placeholder text and add real images from Figma.
- Add responsive tweaks to match Figma exactly.
- Connect to a backend API to persist progress.
