import React, { useState } from "react";

/**
 * LandingPage / Assignment App
 * - Dynamic content driven from local variable `pageData`
 * - Simple, clean UI without external CSS frameworks
 */

const initialData = {
  title: "DeepThought — Web Development",
  subtitle: "Build. Learn. Ship.",
  heroText: "Become a Full Stack Developer. Start small, ship fast.",
  features: [
    "React.js based UI",
    "Node.js backend examples",
    "Project-based learning"
  ],
  cta: { label: "Get Started", url: "#" },
  modules: [
    { id: 1, name: "Intro to React", status: "Not started" },
    { id: 2, name: "State & Props", status: "In progress" },
    { id: 3, name: "Backend APIs", status: "Locked" }
  ]
};

export default function App() {
  const [pageData, setPageData] = useState(initialData);

  function markComplete(id) {
    setPageData(prev => ({
      ...prev,
      modules: prev.modules.map(m => m.id === id ? { ...m, status: "Completed" } : m)
    }));
  }

  return (
    <div className="container">
      <header className="header">
        <h1>{pageData.title}</h1>
        <p className="subtitle">{pageData.subtitle}</p>
      </header>

      <main>
        <section className="hero">
          <h2>{pageData.heroText}</h2>
          <ul className="features">
            {pageData.features.map((f, i) => <li key={i}>{f}</li>)}
          </ul>
          <a className="cta" href={pageData.cta.url}>{pageData.cta.label}</a>
        </section>

        <section className="modules">
          <h3>Modules</h3>
          {pageData.modules.map(m => (
            <div key={m.id} className="module">
              <div>
                <div className="mod-name">{m.name}</div>
                <div className="mod-status">{m.status}</div>
              </div>
              <div>
                <button onClick={() => markComplete(m.id)} disabled={m.status === "Completed"}>
                  Mark Complete
                </button>
              </div>
            </div>
          ))}
        </section>
      </main>

      <footer className="footer">
        Tip: edit the <code>initialData</code> in <code>src/App.jsx</code> to match Figma content.
      </footer>
    </div>
  );
}
